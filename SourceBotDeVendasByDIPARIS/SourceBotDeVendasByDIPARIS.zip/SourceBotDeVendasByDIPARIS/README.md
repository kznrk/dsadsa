# Bot de vendas automáticas por PIX (original)

## Nota de esclarecimento

Recentemente tem circulado muitos bots de vendas por ai no Discord, bot do Linn, done, Space Store, Slayer e etc,
todos esses bots que sejam muito parecidos com esse aqui são modificações desse código ou versões anteriores desse,
esse sistema foi originalmente desenvolvido do zero por mim, **Vanilla#8414**, todo e qualquer bot de vendas que tenha surgido depois do dia 04/06/2022 e pareça no mínimo com esse é **provavelmente** uma modificação desse código aqui.
Essa aqui é a versão com carrinho, a versão anterior é a versão sem carrinho que envia o QR Code no chat do produto só pra pessoa ver.

Já que vazaram o código e surgiram muitas modificações, eu resolvi liberar a minha versão original finalizada
e mais estável, com alguns bugs corrigidos e com sistema de gerenciar estoque, que até onde eu sei, não vazou.
Como foi eu que criei esse sistema do zero, ninguém entende melhor dele do que eu.

## Sobre o projeto

- Projeto encerrado sem planos para novos updates
- Feito pra funcionar usando discord.js v13
- Esse projeto NÃO FUNCIONA corretamente na replit _free_ devido essa gambiarra que vocês fazem dela ficar desligando e pingando
- Não dou suporte gratuito, se quiser ajuda >> minha << pra rodar ou modificar, o suporte é pago
- Não deve funcionar corretamente no Termux devido ao Android enterrar processos em _background_ por muito tempo pra recuperar recursos
- Para rodar o projeto basta preencher o `config.json` com as credenciais e executar
- Se conseguir rodar o projeto, não custa nada me dar os créditos
- Qualquer bug ou problema é por sua conta (exceto que você pague pelo suporte)
- Caso queira me contatar para pagar por suporte ou pedir alguma modificação no sistema, me chame no Discord **Vanilla#8414**,
  vá direto ao ponto com o que você quer, se você me chamar com "oi", "ou", "ei", "tá por ai?" nem vou responder, já chega dizendo que quer suporte
- Tinha muitas coisas que eu ainda queria melhorar no sistema, mas devido esse contrabando desenfreado do sistema eu desanimei de fazer qualquer coisa,
  nunca tinha visto um tráfico de código nesse nível

## Caso queira me pagar um salgado, entra [nesse site](https://onlyvanilla.vercel.app/) 🥰


Feito com muito esforço e sofrimento por **Vanilla#8414** ![corao](https://cdn.discordapp.com/emojis/801789753577177128.gif?size=16&quality=lossless)
